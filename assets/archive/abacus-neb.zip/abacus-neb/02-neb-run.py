# JamesMisaka in 2023-11-27
# Run NEB calculation on NEB images by ASE-ABACUS
# part of ATST-Tools scripts

from ase.optimize import FIRE, BFGS
from ase.io import read, write
from abacus_neb import AbacusNEB

# 1. ABACUS Setup
mpi = 8                  # MPI，等价于：mpirun -np xxx
omp = 4                  # OpenMP，等价于：export OMP_NUM_THREADS=xxx
abacus = "abacus"        # abacus可执行文件路径

# 2. ASE 优化器设置
fmax = 0.05                    # 力收敛判据，单位：eV/Å
neb_optimizer = FIRE           # 结构优化器
neb_directory = "NEBrun"       # NEB计算目录
algorism = "improvedtangent"   # NEB算法
climb = True
dyneb = False  
parallel = False               # 是否并行。默认是串行计算（即挨个算完每个NEB image）
k = 0.10                       # Spring Constant
init_chain = "neb-init.traj"   # 初始NEB初猜

# 3. 赝势基组
pseudo_dir = f"./PP"          # 赝势路径
basis_dir = f"./ORB"          # 基组路径
pp = {
      'C':'C_ONCV_PBE-1.0.upf',
      'H':'H_ONCV_PBE-1.0.upf',
      'Pt':'Pt_ONCV_PBE-1.0.upf',
      }
basis = {
         'C': 'C_gga_7au_100Ry_2s2p1d.orb',
         'H': 'H_gga_6au_100Ry_2s1p.orb',
         'Pt': 'Pt_gga_7au_100Ry_4s2p2d1f.orb',
         }

# 4. ABACUS 计算参数
kpts = [2, 1, 2]
parameters = {
    'calculation': 'scf',
    'nspin': 2,
    'xc': 'pbe',
    'ecutwfc': 100,
    'dft_functional': 'pbe',
    'ks_solver': 'genelpa',
    'symmetry': 0,
    'vdw_method': 'd3_bj',
    'smearing_method': 'gaussian',
    'smearing_sigma': 0.001,
    'basis_type': 'lcao',
    'mixing_type': 'broyden',
    'scf_thr': 1e-6,
    'scf_nmax': 100,
    'kpts': kpts,
    'pp': pp,
    'basis': basis,
    'pseudo_dir': pseudo_dir,
    'basis_dir': basis_dir,
    'init_wfc': 'atomic',
    'init_chg': 'atomic',
    'cal_force': 1,
    'cal_stress': 1,
    'out_stru': 1,
    'out_chg': 0,
    'out_mul': 0,
    'out_wfc_lcao': 0,
    'out_bandgap': 0,
    'efield_flag': 1,
    'dip_cor_flag': 1,
    'efield_dir': 1,
}


if __name__ == "__main__":

    # Main function
    init_chain = read(init_chain, index=':')
    neb = AbacusNEB(init_chain, parameters=parameters, parallel=parallel,
                    directory=neb_directory, mpi=mpi, omp=omp, abacus=abacus, 
                    algorism=algorism, k=k, dyneb=dyneb)
    neb.run(optimizer=neb_optimizer, climb=climb, fmax=fmax)

